package Clases;

public class Pregunta {
}
