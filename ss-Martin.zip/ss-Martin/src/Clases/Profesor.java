package Clases;

public class Profesor {
}
